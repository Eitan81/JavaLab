package Exercise5Conditions;

/**
 * Created by Eitan on 15/12/2017.
 */
public class Printer {
    public static void main(String[] args) {
        String part1 = "There will be";
        int visitors = 5;
        String part2 = "people for dinner";
        System.out.println(part1 + " " + (visitors + 2) + " " + part2);

    }

}
