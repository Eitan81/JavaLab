package Test;

import java.util.Random;

/**
 * Created by Eitan on 17/01/2018.
 */
public class Game {
    public static void main(String[] args) {
        int macabbi = 0, hapoel = 0 ,scoreM = 0, scoreH = 0,i;
        String status = null;
        System.out.println("Tournament between: \n" + "Team" + ":");
        System.out.println("Goalkeeper: " + "Goalkeeper");
        System.out.println("Defensive: " + "DefensPlayer");
        System.out.println("Defensive: " + "DefensPlayer");
        System.out.println("Offensive: " + "OffensPlayer");
        System.out.println("Offensive: " + "OffensPlayer");

        System.out.println("\n" + "Team" + ":");
        System.out.println("Goalkeeper: " + "Goalkeeper");
        System.out.println("Defensive: " + "DefensPlayer");
        System.out.println("Defensive: " + "DefensPlayer");
        System.out.println("Offensive: " + "OffensPlayer");
        System.out.println("Offensive: " + "OffensPlayer");

        Random random = new Random();
        scoreM = random.nextInt(3);
        scoreH = random.nextInt(3);

        for(i=1; i<=4; i++){

            if (scoreM > scoreH ){
                macabbi += 3;
                status = "Macabbi wins!";
            }
            else if (scoreM == scoreH ){
                hapoel += 1;
                macabbi += 1;
                status = "Draw!";
            }
            else {
                hapoel += 3;
                status = "Hapoel wins!";
            }
            System.out.println("Game #" + i +": " + "Team +  VS  + Team => " + scoreM + " : " + scoreH + ", "+  status );
            System.out.println("Score: " + "Team " + scoreM + " Team  => " + scoreH  );
            scoreH = 0;
            scoreM =0;
        }

        if (macabbi > hapoel ){
            status = "Macabbi wins!";
        }
        else if (macabbi == hapoel ){
            status = "Draw!";
        }
        else {
            status = "Hapoel wins!";
            System.out.println(status + " Tournament");
        }

    }
}
