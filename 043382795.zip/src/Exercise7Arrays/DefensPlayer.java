package Exercise7Arrays;

/**
 * Created by Eitan on 17/01/2018.
 */
public class DefensPlayer extends Player {
    super(name);



}
