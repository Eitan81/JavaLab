package Exercise7Arrays;

/**
 * Created by Eitan on 17/01/2018.
 */
public class Team {
    private String teamName;
    private int points;
    private int score;
    public Team(String teamName, int points) {
        this.teamName = teamName;

        Points = points;

    }

    public String getTeamName() {
        return teamName;
    }

    public void setTeamName(String teamName) {
        this.teamName = teamName;
    }

    public int getPoints() {
        return Points;
    }

    public void setPoints(int points) {
        Points = points;
    }

    @Override
    public String toString() {
        return "Team{" +
                "teamName='" + teamName + '\'' +
                ", points=" + points +
                '}';
    }
}
