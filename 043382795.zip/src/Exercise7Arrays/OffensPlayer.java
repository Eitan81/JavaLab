package Exercise7Arrays;

/**
 * Created by Eitan on 17/01/2018.
 */
public class OffensPlayer extends Player  {
    super(name);
}
