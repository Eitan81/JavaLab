package b4test;

/**
 * Created by Eitan on 17/12/2017.
 */
public class Calculation {
    int parameter;

    public Calculation(int parameter) {
        this.parameter = parameter;
    }

    public String calculate() {
        return "in Calculation class";
    }
}
